import React from "react";

import MenuThree from "./menu/MenuThree";

export default function HeaderFour({ container }) {
  return <MenuThree />;
}
