import React from "react";

export default function error() {
  return (
    <div>
      <h1>404 not found</h1>
    </div>
  );
}
